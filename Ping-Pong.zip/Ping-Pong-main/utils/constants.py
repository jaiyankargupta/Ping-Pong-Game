# Initialize slider variables
WIDTH, HEIGHT = 700, 500
ball_radius = 15
# Decrease the height for a horizontal slider
PADDLE_WIDTH, PADDLE_HEIGHT = 150, 20
WHITE = (255, 255, 255)
slider_color = (255, 255, 255)
# speed increment factor
speed_increment = 1.3